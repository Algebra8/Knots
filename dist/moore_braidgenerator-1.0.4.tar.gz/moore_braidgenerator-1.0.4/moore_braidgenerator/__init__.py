from .braidword import BraidWord
from .markovchain import MarkovChain
__version__ = '1.0.4'
